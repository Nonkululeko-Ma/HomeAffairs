<?php
/**
 * Require all of your model classes here so that you can just require this one file whenever you want to
 * interact with the database
 */
require_once __DIR__.'/User.php';